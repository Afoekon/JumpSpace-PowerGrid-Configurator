# 🛠️ JumpSpace Power Grid Configurator

A browser‑based tool that lets players of **Jump Space** visualize and configure their ship’s power grids.
This utility helps plan power layouts for different ship chassis, reactors, and auxiliary generators before applying them in‑game.

![Screenshot](assets/screenshot.png)

## 🚀 Features
- Select ship chassis, reactor, and auxiliary generators
- Preview power coverage dynamically across a 16×8 grid
- Drag‑and‑drop ship components onto the grid
- Rotate components with right‑click
- Powered/unpowered cell highlighting
- Reset by category or all components

## 🧩 How to Use
1. Open `index.html` in any modern browser.
2. Choose your ship chassis, reactor, and auxiliary generators.
3. Drag components from the **Component Palette** onto the grid.
4. Right‑click a component to rotate it.
5. Watch the grid colors to see what’s powered (green) or protected (blue).

## 🛠 Tech
- **HTML**, **Tailwind CSS**, **vanilla JavaScript**
- Runs entirely client‑side (no server required)

## 📄 Credits
Created by **Jeffrey Ragsdale** as a fan project for *Jump Space*.

---

> Tip: You can host this with **GitHub Pages**. Put this file and `index.html` on the `main` branch and enable Pages in repo settings.
